import { Component } from '@angular/core';
import {MatCardModule} from "@angular/material/card";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatInputModule} from "@angular/material/input";
import {MatButton} from "@angular/material/button";
import {MatIcon} from "@angular/material/icon";
import {MatDivider} from "@angular/material/divider";
import {AuthService} from "../../services/user_services/auth.service";
import {FormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";

@Component({
  selector: 'app-register',
  standalone: true,
  providers: [AuthService],
  imports: [MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButton,
    MatIcon, MatDivider, FormsModule, HttpClientModule ],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  firstName: string = "";
  lastName: string = "";
  username: string = "";
  email: string = "";
  password: string = "";
  repeatPassword: string = "";


  constructor(private authService: AuthService) { }

  register(): void {
    // Call AuthService.register with the form values
    this.authService.register(this.email, this.password, this.firstName, this.lastName)
      .subscribe(
        response => {
          console.log('Registration successful:', response);
          // Handle success, e.g., show a success message or redirect to login page
        },
        error => {
          console.error('Registration failed:', error);
          // Handle error, e.g., show an error message
        }
      );
  }

}
